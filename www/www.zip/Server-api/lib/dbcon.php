<?php
	
	

$con=mysql_Connect("localhost","root","")or die("connection aborted");
	mysql_select_db("prop")or die("Not Selected");
	
	
	
	
	
?>