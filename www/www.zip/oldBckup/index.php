<a href="<?php echo $_SERVER["REQUEST_URI"];?>">Refresh</a>

<title>Welcome to Apna Site.in! :-)</title>
<h1>Welcome to Apna Site.in! :-)</h1>

<?php
	$i = 0;
	while($i <= 10){
		echo $i."<br>";
		$i++;
	}
?>